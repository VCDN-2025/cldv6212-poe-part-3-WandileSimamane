﻿using Azure;
using Azure.Data.Tables;
using Azure.Storage.Blobs;
using Microsoft.Extensions.Configuration;
using OrderSystem.Services.Shared.Models;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

namespace OrderSystem.Services.Services
{
    public class TableService
    {
        private readonly string _connectionString;

        public TableService(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("AzureStorage")
                ?? config["AzureWebJobsStorage"]
                ?? throw new InvalidOperationException("Azure storage connection string missing. Expected: ConnectionStrings:AzureStorage or AzureWebJobsStorage");
        }
        public TableClient GetTableClient(string tableName)
        {
            var client = new TableClient(_connectionString, tableName);
            client.CreateIfNotExists();
            return client;
        }

        public async Task CreateAllTablesAsync()
        {
            var tableNames = new[] { "Product", "Order", "Login", "Customer", "CartItem" };
            foreach (var name in tableNames)
            {
                var client = GetTableClient(name);
                await client.CreateIfNotExistsAsync();  
            }
        }
        public async Task<List<Login>> GetAllLoginsAsync()
        {
            var client = GetTableClient("Login");
            var list = new List<Login>();
            await foreach (var login in client.QueryAsync<Login>())
            {
                list.Add(login);
            }
            return list;
        }
        // Customer methods (no change)
        public async Task AddCustomerAsync(Customer customer)
        {
            var client = GetTableClient("Customer");
            await client.AddEntityAsync(customer);
        }

        public async Task UpdateCustomerAsync(Customer customer)
        {
            var client = GetTableClient("Customer");
            await client.UpdateEntityAsync(customer, ETag.All, TableUpdateMode.Replace);
        }

        public async Task DeleteCustomerAsync(string rowKey)
        {
            var client = GetTableClient("Customer");
            await client.DeleteEntityAsync("Customer", rowKey);
        }

        public async Task<Customer?> GetCustomerAsync(string rowKey)
        {
            try
            {
                var client = GetTableClient("Customer");
                var response = await client.GetEntityAsync<Customer>("Customer", rowKey);
                return response.Value;
            }
            catch (RequestFailedException)
            {
                return null;
            }
        }

        public async Task<List<Customer>> GetAllCustomersAsync()
        {
            var client = GetTableClient("Customer");
            var customers = new List<Customer>();
            await foreach (var customer in client.QueryAsync<Customer>())
            {
                customers.Add(customer);
            }
            return customers;
        }

        // Product methods
        public async Task AddProductAsync(Product product)
        {
            var client = GetTableClient("Product");
            await client.AddEntityAsync(product);
        }

        public async Task UpdateProductAsync(Product product)
        {
            var client = GetTableClient("Product");
            await client.UpdateEntityAsync(product, ETag.All, TableUpdateMode.Replace);
        }

        public async Task DeleteProductAsync(string rowKey)
        {
            var client = GetTableClient("Product");
            await client.DeleteEntityAsync("Product", rowKey);
        }

        public async Task<Product?> GetProductAsync(string rowKey)
        {
            try
            {
                var client = GetTableClient("Product");
                var response = await client.GetEntityAsync<Product>("Product", rowKey);
                return response.Value;
            }
            catch (RequestFailedException)
            {
                return null;
            }
        }

        public async Task<List<Product>> GetAllProductsAsync()
        {
            var client = GetTableClient("Product");
            var products = new List<Product>();
            await foreach (var product in client.QueryAsync<Product>())
            {
                products.Add(product);
            }
            return products;
        }

        // Login methods (normalized username)
        public async Task AddLoginAsync(Login login)
        {
            login.Username = login.Username.Trim().ToLower();
            login.RowKey = Guid.NewGuid().ToString();
            var client = GetTableClient("Login");
            await client.AddEntityAsync(login);
        }

        public async Task<Login?> GetLoginByUsernameAsync(string username)
        {
            if (string.IsNullOrWhiteSpace(username)) return null;

            username = username.Trim().ToLower();
            var client = GetTableClient("Login");

            await foreach (var login in client.QueryAsync<Login>(l => l.Username == username))
            {
                return login;  
            }
            return null;
        }

        public async Task<Login?> GetLoginByIdAsync(string rowKey)
        {
            if (string.IsNullOrWhiteSpace(rowKey)) return null;

            var client = GetTableClient("Login");
            try
            {
                var resp = await client.GetEntityAsync<Login>("Login", rowKey);
                return resp.Value;
            }
            catch
            {
                return null;
            }
        }

        // Cart methods
        public async Task<List<CartItem>> GetCartItemsAsync(string partitionKey)
        {
            var client = GetTableClient("CartItem");
            var items = new List<CartItem>();
            await foreach (var item in client.QueryAsync<CartItem>(i => i.PartitionKey == partitionKey))
            {
                items.Add(item);
            }
            return items;
        }

        public async Task AddCartItemAsync(CartItem item)
        {
            var client = GetTableClient("CartItem");
            await client.AddEntityAsync(item);
        }

        public async Task UpdateCartItemAsync(CartItem item)
        {
            var client = GetTableClient("CartItem");
            await client.UpdateEntityAsync(item, ETag.All, TableUpdateMode.Replace);
        }

        public async Task DeleteCartItemAsync(string partitionKey, string rowKey)
        {
            var client = GetTableClient("CartItem");
            await client.DeleteEntityAsync(partitionKey, rowKey);
        }

        public async Task<List<CartItem>> GetAllCartItemsAsync()
        {
            var client = GetTableClient("CartItem");
            var items = new List<CartItem>();
            await foreach (var item in client.QueryAsync<CartItem>())
            {
                items.Add(item);
            }
            return items;
        }

        // Order methods
        public async Task AddOrderAsync(Order order)
        {
            var client = GetTableClient("Order");
            await client.AddEntityAsync(order);
        }

        public async Task UpdateOrderAsync(Order order)
        {
            var client = GetTableClient("Order");
            await client.UpdateEntityAsync(order, ETag.All, TableUpdateMode.Replace);
        }

        public async Task<string> ConvertCartToOrderAsync(string userId)
        {
            var items = await GetCartItemsAsync(userId);
            if (!items.Any()) throw new Exception("Cart empty.");

            var order = new Order
            {
                RowKey = Guid.NewGuid().ToString(),
                CustomerId = userId,
                Items = items.Select(i => new OrderItem
                {
                    ProductId = i.ProductId,
                    ProductName = i.ProductName,
                    Quantity = i.Quantity,
                    Price = i.Price
                }).ToList(),
                TotalAmount = items.Sum(i => i.Price * i.Quantity)
            };

            await AddOrderAsync(order);

            foreach (var item in items)
            {
                await DeleteCartItemAsync(userId, item.RowKey);
            }

            return order.RowKey;
        }
    }
}