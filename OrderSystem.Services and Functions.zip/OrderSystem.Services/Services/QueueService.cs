﻿using Azure.Storage.Queues;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;

namespace OrderSystem.Services.Services
{
    public class QueueService
    {
        private readonly string _connectionString;

        public QueueService(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("AzureStorage")
                ?? config["AzureWebJobsStorage"]
                ?? throw new InvalidOperationException("Azure storage connection string missing. Expected: ConnectionStrings:AzureStorage or AzureWebJobsStorage");
        }
        public async Task SendMessageAsync(string queueName, string? message)
        {
            message ??= string.Empty;
            if (string.IsNullOrEmpty(queueName)) throw new ArgumentNullException(nameof(queueName));
            if (message == null) message = string.Empty;

            var client = new QueueClient(_connectionString, queueName);
            await client.CreateIfNotExistsAsync();
            await client.SendMessageAsync(Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(message)));
           
        }
    }
}
