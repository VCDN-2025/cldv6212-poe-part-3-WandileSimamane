﻿using OrderSystem.Services.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace OrderSystem.Services.Services
{
    public class CartService
    {
        private readonly TableService _tableService;

        private readonly QueueService _queueService;
        public CartService(TableService tableService, QueueService queueService)
        {
            _tableService = tableService;
            _queueService = queueService;
        }

        public async Task<List<CartItem>> GetCartItemsAsync(string userId)
        {
            return await _tableService.GetCartItemsAsync(userId);
        }

        public async Task AddItemAsync(string userId, string productId, int quantity)
        {
            if (quantity <= 0) throw new ArgumentOutOfRangeException(nameof(quantity));

            var items = await GetCartItemsAsync(userId);
            var existing = items.FirstOrDefault(i => i.ProductId == productId);

            if (existing != null)
            {
                existing.Quantity += quantity;
                await _tableService.UpdateCartItemAsync(existing);
            }
            else
            {
                var product = await _tableService.GetProductAsync(productId)
                              ?? throw new Exception("Product not found");

                var item = new CartItem
                {
                    PartitionKey = userId,
                    RowKey = Guid.NewGuid().ToString(),
                    ProductId = productId,
                    ProductName = product.ProductName,
                    Quantity = quantity,
                    Price = product.Price,
                    ProductImage = product.ProductImage ?? string.Empty
                };
                await _tableService.AddCartItemAsync(item);
            }
        }

        public async Task UpdateQuantityAsync(string cartItemId, int quantity)
        {
            var items = await _tableService.GetAllCartItemsAsync();
            var item = items.FirstOrDefault(i => i.RowKey == cartItemId) ?? throw new Exception("Cart item not found.");
            item.Quantity = quantity > 0 ? quantity : 0;
            await _tableService.UpdateCartItemAsync(item);
        }
        public async Task RemoveItemAsync(string userId, string cartItemRowKey)
        {
            if (string.IsNullOrEmpty(userId)) throw new ArgumentNullException(nameof(userId));
            if (string.IsNullOrEmpty(cartItemRowKey)) throw new ArgumentNullException(nameof(cartItemRowKey));
            await _tableService.DeleteCartItemAsync(userId, cartItemRowKey);
        }
        public async Task<Product?> GetProductByIdAsync(string productId)
        {
            return await _tableService.GetProductAsync(productId);
        }

        public async Task<string> CheckoutAsync(string userId)
        {
            if (string.IsNullOrEmpty(userId)) throw new ArgumentNullException(nameof(userId));

            var items = await GetCartItemsAsync(userId);
            if (!items.Any()) throw new InvalidOperationException("Cart is empty.");

            // Get customer email from Login table
            var login = await _tableService.GetLoginByIdAsync(userId);
            var customerEmail = login?.email ?? "unknown@example.com";

            var order = new Order
            {
                PartitionKey = "Order",
                RowKey = Guid.NewGuid().ToString(),
                CustomerId = userId,
                CustomerEmail = customerEmail,
                OrderDate = DateTimeOffset.UtcNow,
                Status = "Pending",
                TotalAmount = items.Sum(i => i.Price * i.Quantity),
                Items = items.Select(i => new OrderItem
                {
                    ProductId = i.ProductId,
                    ProductName = i.ProductName,
                    Quantity = i.Quantity,
                    Price = i.Price
                }).ToList()

            };

            await _tableService.AddOrderAsync(order);
            await _queueService.SendMessageAsync(
     "transactions-queue",
     JsonSerializer.Serialize(new { OrderId = order.RowKey, Total = order.TotalAmount })
 );

            // Clear cart
            foreach (var item in items)
            {
                await _tableService.DeleteCartItemAsync(userId, item.RowKey);
            }

            return order.RowKey;
        }

    }
}