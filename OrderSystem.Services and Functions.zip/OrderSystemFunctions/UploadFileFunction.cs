﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using OrderSystem.Services.Services;
using OrderSystemFunctions.Models;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;

namespace OrderSystemFunctions
{
    public class UploadFileFunction
    {
        private readonly FileService _fileService;

        public UploadFileFunction(FileService fileService)
        {
            _fileService = fileService;
        }

        [Function("UploadFile")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req,
            FunctionContext context)
        {
            using var reader = new StreamReader(req.Body);
            var json = await reader.ReadToEndAsync();
            var data = JsonSerializer.Deserialize<FileUploadRequest>(json);

            if (data == null)
                return req.CreateResponse(System.Net.HttpStatusCode.BadRequest);

            var fileBytes = Convert.FromBase64String(data.Base64FileContent);

            await _fileService.UploadFileAsync(data.FileName, fileBytes, "contracts");

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            await response.WriteStringAsync("File uploaded to Azure File Share");
            return response;
        }
    }
}
