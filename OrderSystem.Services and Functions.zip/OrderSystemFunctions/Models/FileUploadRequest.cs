﻿namespace OrderSystemFunctions.Models
{
    public class FileUploadRequest
    {
        public string FileName { get; set; } = string.Empty;
        public string Base64FileContent { get; set; } = string.Empty;
    }
}
