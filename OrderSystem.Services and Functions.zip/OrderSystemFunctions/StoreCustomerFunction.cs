using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using OrderSystem.Services.Services;
using OrderSystem.Services.Shared.Models;
using System.Text.Json;
using System.Threading.Tasks;

namespace OrderSystemFunctions
{
    public class StoreCustomerFunction
    {
        private readonly TableService _tableService;

        public StoreCustomerFunction(TableService tableService)
        {
            _tableService = tableService;
        }

        [Function("StoreCustomer")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req,
            FunctionContext context)
        {
            var log = context.GetLogger("StoreCustomer");
            log.LogInformation("Storing customer...");

            var body = await req.ReadAsStringAsync();
            var customer = JsonSerializer.Deserialize<Customer>(body);

            if (customer == null)
                return req.CreateResponse(System.Net.HttpStatusCode.BadRequest);

            await _tableService.AddCustomerAsync(customer);

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            await response.WriteStringAsync("Customer stored successfully");
            return response;
        }
    }
}