﻿
using Azure.Storage.Blobs;
using Azure.Storage.Files.Shares;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using OrderSystem.Services.Services;

[assembly: FunctionsStartup(typeof(OrderSystemFunctions.Startup))]

namespace OrderSystemFunctions
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            var config = builder.GetContext().Configuration;

            string storageConnection = config.GetConnectionString("AzureTableStorage")
                ?? config["AzureWebJobsStorage"]
                ?? throw new InvalidOperationException("Azure storage connection string missing for functions.");


            builder.Services.AddSingleton(_ => new BlobServiceClient(storageConnection));
            builder.Services.AddSingleton(_ => new ShareServiceClient(storageConnection));

        
            builder.Services.AddSingleton<TableService>();
            builder.Services.AddSingleton<BlobService>();
            builder.Services.AddSingleton<FileService>();
            builder.Services.AddSingleton<QueueService>();
            builder.Services.AddScoped<CartService>();
        }
    }
}
