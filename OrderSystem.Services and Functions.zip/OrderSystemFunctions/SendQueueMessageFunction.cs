﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using OrderSystem.Services.Services;
using System.Text.Json;
using System.Threading.Tasks;
namespace OrderSystemFunctions
{
    public class QueueMessageFunction
    {
        private readonly QueueService _queueService;

        public QueueMessageFunction(QueueService queueService)
        {
            _queueService = queueService;
        }

        [Function("SendQueueMessage")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req,
            FunctionContext context)
        {
            var log = context.GetLogger("SendQueueMessage");
            log.LogInformation("Sending message to queue...");

            var body = await req.ReadAsStringAsync();
            await _queueService.SendMessageAsync("transactions-queue", body);

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            await response.WriteStringAsync("Message sent to queue");
            return response;
        }
    }
}