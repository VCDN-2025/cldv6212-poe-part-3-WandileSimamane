﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;

namespace OrderSystem.Services.Shared.Models
{
    public class CartItem : ITableEntity
    {
        public string PartitionKey { get; set; } = string.Empty;
        public string RowKey { get; set; } = Guid.NewGuid().ToString();

        [Required] public string ProductId { get; set; } = string.Empty;
        [Required] public string ProductName { get; set; } = string.Empty;
        public string ProductImage { get; set; } = string.Empty; 

        [Required] public decimal Price { get; set; }
        [Required] public int Quantity { get; set; }

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}