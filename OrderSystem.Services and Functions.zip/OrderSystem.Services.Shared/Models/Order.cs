﻿using Azure;
using Azure.Data.Tables;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace OrderSystem.Services.Shared.Models
{
    public class Order : ITableEntity
    {
        public string PartitionKey { get; set; } = "Order";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();

        public string CustomerId { get; set; } = string.Empty;
        public string CustomerEmail { get; set; } = string.Empty;
        public DateTimeOffset OrderDate { get; set; } = DateTimeOffset.UtcNow;
        public string Status { get; set; } = "Pending";
        public decimal TotalAmount { get; set; } = 0m;

        public string ItemsJson { get; set; } = "[]";

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }

        [JsonIgnore]
        public List<OrderItem> Items
        {
            get => JsonSerializer.Deserialize<List<OrderItem>>(ItemsJson) ?? new();
            set => ItemsJson = JsonSerializer.Serialize(value);
        }
    }

    public class OrderItem
    {
        public string ProductId { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public int Quantity { get; set; } = 1;
        public decimal Price { get; set; } = 0m;
    }
}