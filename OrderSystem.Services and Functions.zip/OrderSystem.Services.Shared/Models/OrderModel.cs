﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace OrderSystem.Services.Shared.Models
{
    public class OrderModel
    {
        public string RowKey { get; set; } = string.Empty;
        public string CustomerEmail { get; set; } = string.Empty;
        public DateTimeOffset OrderDate { get; set; }
        public string Status { get; set; } = "Pending";
        public decimal TotalAmount { get; set; }
        public List<OrderItem> Items { get; set; } = new();
    }
}