﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;
namespace OrderSystem.Services.Shared.Models

{
    public class Customer : ITableEntity
    {
        public string PartitionKey { get; set; } = "Customer";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();

        [Required] public string CustomerName { get; set; } = string.Empty;
        [Required, EmailAddress] public string CustomerEmail { get; set; } = string.Empty;

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}
