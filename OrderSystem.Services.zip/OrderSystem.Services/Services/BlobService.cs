﻿using Azure.Storage.Blobs;
using System.IO;
using System.Threading.Tasks;

namespace OrderSystem.Services.Services
{
    public class BlobService
    {
        private readonly BlobServiceClient _client;

        public BlobService(BlobServiceClient client)
        {
            _client = client ?? throw new ArgumentNullException(nameof(client));
        }

       
        public async Task<string> UploadFileAsync(string fileName, byte[] fileBytes, string containerName)
        {
            var container = _client.GetBlobContainerClient(containerName);
            await container.CreateIfNotExistsAsync();

            var blob = container.GetBlobClient(fileName);
            using var ms = new MemoryStream(fileBytes);
            await blob.UploadAsync(ms, overwrite: true);

            return blob.Uri.ToString();
        }
    }
}
