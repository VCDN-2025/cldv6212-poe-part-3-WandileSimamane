﻿using Azure;
using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using System.IO;
using System.Threading.Tasks;

namespace OrderSystem.Services.Services
{
    public class FileService
    {
        private readonly ShareServiceClient _client;

        public FileService(ShareServiceClient client)
        {
            _client = client ?? throw new ArgumentNullException(nameof(client));
        }

        // Uploads a byte to a file share root
        public async Task UploadFileAsync(string fileName, byte[] fileBytes, string shareName)
        {
            var share = _client.GetShareClient(shareName);
            await share.CreateIfNotExistsAsync();

            var root = share.GetRootDirectoryClient();
            var fileClient = root.GetFileClient(fileName);

            using var ms = new MemoryStream(fileBytes);
            await fileClient.CreateAsync(ms.Length);
            await fileClient.UploadRangeAsync(new HttpRange(0, ms.Length), ms);
        }
    }
}
