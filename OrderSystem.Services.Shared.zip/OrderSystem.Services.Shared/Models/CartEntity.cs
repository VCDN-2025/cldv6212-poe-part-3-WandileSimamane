﻿using Azure;
using Azure.Data.Tables;
namespace OrderSystem.Services.Shared.Models

{
    public class CartEntity : ITableEntity
    {
        public string PartitionKey { get; set; } = "Cart";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();
        public string UserId { get; set; } = string.Empty;

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}
