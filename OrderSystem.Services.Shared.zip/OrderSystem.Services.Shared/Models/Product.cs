﻿using Azure;
using Azure.Data.Tables;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;

namespace OrderSystem.Services.Shared.Models
{
    public class Product : ITableEntity
    {
        public string PartitionKey { get; set; } = "Product";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();

        [Required]
        public string ProductName { get; set; } = string.Empty;

        public string ProductDetails { get; set; } = string.Empty;
        public string ProductImage { get; set; } = string.Empty;

        public decimal Price { get; set; }

        [IgnoreDataMember] public DateTimeOffset? Timestamp { get; set; }
        [IgnoreDataMember] public ETag ETag { get; set; }
    }
}
