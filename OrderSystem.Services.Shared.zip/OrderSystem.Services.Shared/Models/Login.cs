﻿using Azure;
using Azure.Data.Tables;
using System.Runtime.Serialization;
namespace OrderSystem.Services.Shared.Models
{

    public class Login : ITableEntity
    {
        public string PartitionKey { get; set; } = "Login";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();
        public string Username { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string Role { get; set; } = "Customer";

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }

        [IgnoreDataMember]
        public string Password { get; set; } = string.Empty;
    }
}