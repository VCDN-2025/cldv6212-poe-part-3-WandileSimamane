﻿using Azure;
using Azure.Data.Tables;
namespace OrderSystem.Services.Shared.Models

{
    public class CartItem : ITableEntity
    {
        public string PartitionKey { get; set; } = string.Empty; // CartId
        public string RowKey { get; set; } = Guid.NewGuid().ToString(); // CartItemId

        public string CartId { get; set; } = string.Empty;
        public string ProductId { get; set; } = string.Empty;
        public int Quantity { get; set; } = 1;
        public string ProductName { get; set; } = string.Empty;
        public decimal Price { get; set; } = 0m;

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}
