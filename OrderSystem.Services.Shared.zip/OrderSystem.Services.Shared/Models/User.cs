﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;

namespace OrderSystem.Services.Shared.Models
{
    public class User : ITableEntity
    {
        public string PartitionKey { get; set; } = "User";
        public string RowKey { get; set; } = Guid.NewGuid().ToString(); 

        [Required]
        public string Username { get; set; } = string.Empty;

        [Required]
        public string PasswordHash { get; set; } = string.Empty;

        public string Role { get; set; } = "Customer"; 

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}
