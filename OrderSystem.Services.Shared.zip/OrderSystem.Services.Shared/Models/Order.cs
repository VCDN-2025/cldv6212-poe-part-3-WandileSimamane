﻿using Azure;
using Azure.Data.Tables;

namespace OrderSystem.Services.Shared.Models
{
    public class Order : ITableEntity
    {
        public string PartitionKey { get; set; } = "Order";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();


        public string ProductId { get; set; } = string.Empty;
        public int Quantity { get; set; } = 1;

        public string CustomerId { get; set; } = string.Empty;
        public DateTimeOffset OrderDate { get; set; } = DateTimeOffset.UtcNow;
        public string Status { get; set; } = "Pending";
        public decimal Total { get; set; } = 0m;

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}
